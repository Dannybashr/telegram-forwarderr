# Telegram Forwarder

A small Telegram bot that forwards messages from one chat to another.

## Files

- `main.py` — bot application
- `requirements.txt` — Python dependency
- `.gitignore` — prevents secrets/local files from being committed

## Railway setup

Create these Railway environment variables:

- `BOT_TOKEN` — your current Telegram bot token
- `SOURCE_CHAT_ID` — numeric ID of the chat the bot should monitor
- `TARGET_CHAT_ID` — numeric ID of the chat that should receive forwarded messages

Do **not** put the bot token in this repository.

## Telegram permissions

For group/supergroup forwarding, add the bot to the source chat and give it permission to read messages (depending on the group's privacy settings). Add the bot to the target chat and give it permission to send messages.

For channels, the bot generally needs to be added as an administrator with the appropriate permissions.

The bot can only forward messages that Telegram delivers to it; it cannot access arbitrary private chats or messages it has no permission to see.

## Run locally

```bash
pip install -r requirements.txt
export BOT_TOKEN="your-token"
export SOURCE_CHAT_ID="-1001234567890"
export TARGET_CHAT_ID="-1009876543210"
python main.py
```

On Railway, use the same variables in the service's Variables section. Railway can start the app with:

```bash
python main.py
```
