import os
import logging
from telegram import Update
from telegram.ext import Application, ContextTypes, MessageHandler, filters

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
SOURCE_CHAT_ID = os.environ.get("SOURCE_CHAT_ID", "")
TARGET_CHAT_ID = os.environ.get("TARGET_CHAT_ID", "")


def parse_chat_id(value: str):
    """Convert an environment value to int when possible."""
    value = value.strip()
    if not value:
        return None
    try:
        return int(value)
    except ValueError:
        return value


SOURCE = parse_chat_id(SOURCE_CHAT_ID)
TARGET = parse_chat_id(TARGET_CHAT_ID)


async def forward_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Forward matching messages from the source chat to the target chat."""
    if not update.effective_chat or not update.effective_message:
        return

    if SOURCE is None or TARGET is None:
        logger.error("SOURCE_CHAT_ID and TARGET_CHAT_ID must be configured.")
        return

    if update.effective_chat.id != SOURCE:
        return

    try:
        await context.bot.forward_message(
            chat_id=TARGET,
            from_chat_id=update.effective_chat.id,
            message_id=update.effective_message.message_id,
        )
        logger.info(
            "Forwarded message %s from %s to %s",
            update.effective_message.message_id,
            SOURCE,
            TARGET,
        )
    except Exception:
        logger.exception("Failed to forward message.")


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Basic health/help response."""
    if update.effective_message:
        await update.effective_message.reply_text(
            "Telegram forwarder is running.\n"
            "Forwarding is controlled by SOURCE_CHAT_ID and TARGET_CHAT_ID."
        )


def main() -> None:
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN environment variable is missing.")
    if SOURCE is None:
        raise RuntimeError("SOURCE_CHAT_ID environment variable is missing.")
    if TARGET is None:
        raise RuntimeError("TARGET_CHAT_ID environment variable is missing.")

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(
        MessageHandler(filters.COMMAND & filters.Regex(r"^/start(?:@\\w+)?$"), start)
    )
    app.add_handler(
        MessageHandler(filters.ALL & ~filters.COMMAND, forward_message)
    )

    logger.info("Telegram forwarder starting...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
